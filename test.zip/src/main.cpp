#include <logging.hpp>
#include <print>
#include <string>
#include <tempfile.hpp>

#include "zip_fs.hpp"

#include "flags.h"

int main(int argc, char** argv) {
    const flags::args args(argc, argv);

	TempDir temp = TempDir::tempdir_here();

	if (args.get<bool>("v", "verbose")) {
	    logging_level = VERBOSE;
	}

	std::optional<std::string> archive_path = args.get<std::string>(0);

	if (archive_path) {
	    std::println("Archive: {}", archive_path.value());
	} else {
	    std::println("Error: Please specify a archive path.");
		return 1;
	}

	ZipFS zfs(argv[1]);

	zfs.run(temp);

	return 0;
}
