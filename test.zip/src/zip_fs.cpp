#include <zip.h>
#include <zip_fs.hpp>
#include <stdexcept>

ZipFS::ZipFS(const std::string& archive_path) : FileSystem(), z(nullptr) {
  		int err;
		z = zip_open(archive_path.c_str(), ZIP_RDONLY, &err);

		if (!z) {
			zip_error_t error;
			zip_error_init_with_code(&error, err);

			std::runtime_error except(zip_error_strerror(&error));
			zip_error_fini(&error);

			throw except;
		}
}

ZipFS::~ZipFS() {
    zip_close(z);
}
